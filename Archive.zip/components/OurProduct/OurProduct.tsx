import Image from 'next/image'
import React from 'react'
import Gif from "../../public/assets/img/png/barbatos.png"
export const OurProduct = () => {
  return (
    <div className='flex justify-between h-full bg-[#e2e2e2] p-4 relative'>
      

    </div>
  )
}

"use strict";
exports.id = 524;
exports.ids = [524];
exports.modules = {

/***/ 8524:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "A": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/assets/img/Forest.png
/* harmony default export */ const Forest = ({"src":"/_next/static/media/Forest.1cfa8522.png","height":761,"width":2334,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAQAAAAEwYbDAAAAM0lEQVR42i3BQREAEQAAwL0Q973rQBAVFFJDG38JjA4efOzyAR5XkUU/guRl2aauGrZ2AHGwCQeELc01AAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/assets/img/Forest2.png
/* harmony default export */ const Forest2 = ({"src":"/_next/static/media/Forest2.f5541a95.png","height":1016,"width":1920,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAQAAAAZxLZ7AAAARUlEQVR42h3FsQ1AQAAAwMuLUmMEKzCHwgT2sIFGbwV7WMEKKlFpSPznrzkCKLTKPGqVxqQT9Axmm8VhNdo5XV6PL337I++KDc4O+Tc+AAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/Footer/Footer.tsx





const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "fixed z-[-1] w-full bottom-0",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: "opacity-10 z-[0] animation-backgroundone ",
                src: Forest2
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: "opacity-10 z-[0] animation-backgroundtwo animation-background2",
                src: Forest
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: "opacity-10 z-[-1] animation-background ",
                src: Forest
            })
        ]
    });
};

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
;// CONCATENATED MODULE: ./components/Header/Header.tsx




const Header = ()=>{
    const MediaQuery = dynamic_default()(null, {
        loadableGenerated: {
            modules: [
                "../components/Header/Header.tsx -> " + "react-responsive"
            ]
        },
        ssr: false
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(MediaQuery, {
                maxWidth: 768,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "p-6 bg-transparent flex w-full space-x-7 z-50 bg-inherit fixed text-stone-200 ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            children: "Homepage"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/colelction",
                            children: "Colection"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/aboutus",
                            children: "About Us"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(MediaQuery, {
                minWidth: 768,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "p-6 bg-transparent flex z-50 w-full space-x-7 fixed text-stone-200 bg-gradient-to-br from-[#323232] via-[#4b4b4b3d] to-[#08070700] tracking-widest",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            children: "Homepage"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/colelction",
                            children: "Colection"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/aboutus",
                            children: "About Us"
                        })
                    ]
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/layout/Layout.tsx





const Layout = (props)=>{
    const { children , pageTitle  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-gradient-to-br from-[#1f1f1f50] via-[#000000bf] to-[#080707]",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: pageTitle
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Black Wolf Tech Indonesia"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Header, {}),
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(Footer, {})
        ]
    });
};


/***/ })

};
;